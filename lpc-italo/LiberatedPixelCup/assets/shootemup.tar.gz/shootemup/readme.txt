SHOOT'EM UP GRAPHIC KIT README
==============================

My submission for the "Liberated Pixel Cup" is a complete graphic kit for "shoot'em up" games.

It is composed by a complete background tileset, some aircraft sheets and... a zombie rotten tomato animation. Yeah, I don't like to destroy other aircrafts. Tomatoes, it's OK.
Even if the submitted images are all released under a bitmap format (PNG), I only worked with descriptive formats like SVG and 3D blender's. The whole graphic kit is just a direct conversion made from these raw graphics. I made this choice because I really think that free art (like the ones licensed in GPL) can only be done this way.

A bitmap is a sampling, and as every sampling, it is a lack of information. User is not free to zoom in, for example. A lack of information is also a loss of freedom. That's why I think that only descriptive formats can be really free.

COPYRIGHT AND LICENSE
=====================

All graphic resources are released under CC-BY-SA 3.0 licence, the GNU GPL Version 3 and the GNU LGPL Version 3. Later versions are permitted.

LINKS
=====

Homepage  http://poufpoufproduction.fr
Email     johannc@poufpoufproduction.fr
